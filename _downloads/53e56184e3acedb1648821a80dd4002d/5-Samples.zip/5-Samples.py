"""
Samples (Analysis and Visualization)
====================================

This tutorial will cover the basic concepts of how to analyze and visualize samples in CUQIpy.

"""
# %%
import cuqi

# %%
#
# .. todo::
#    Continue tutorial here.
