"""
Distributions
=============

This tutorial will cover the basic concepts of distributions. In particular how to construct a distributions in various forms.

The most important concept of distributions in CUQIpy are the fact that they can be conditioned on some variables.

"""
# %%
import cuqi

# %%
#
# .. todo::
#    Continue tutorial here.
